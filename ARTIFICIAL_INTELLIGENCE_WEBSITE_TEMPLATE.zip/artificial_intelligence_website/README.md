# ARTIFICIAL INTELLIGENCE — Website Template

Template website edukasi dengan 7 menu utama dan 49 halaman materi.

## Isi folder
- `index.html` — struktur utama website
- `styles.css` — seluruh desain, warna, layout, dan responsivitas
- `app.js` — navigasi, isi halaman, pencarian, dan formulir kontak

## Cara membuka
1. Ekstrak file ZIP.
2. Buka folder `artificial_intelligence_website`.
3. Klik dua kali `index.html` atau buka dengan Chrome/Edge.
4. Website dapat berjalan secara lokal tanpa instalasi.

## Cara mengedit
- **Mengubah teks materi, judul, deskripsi, dan daftar halaman:** buka `app.js`, cari `const SITE_DATA = ...` di bagian paling atas. Data halaman disimpan dalam objek `SITE_DATA`.
- **Mengubah warna, ukuran tulisan, dan desain:** buka `styles.css`, ubah nilai warna pada bagian `:root`.
- **Mengubah nama situs dan metadata:** buka `index.html`.
- **Mengubah alamat email formulir:** di `app.js`, cari `ISI_EMAIL_KAMU` lalu ganti dengan alamat email yang ingin digunakan.

Gunakan editor teks seperti Visual Studio Code, Notepad++, atau Notepad. Simpan perubahan lalu refresh browser.

## Formulir kontak
Formulir contoh menyiapkan pesan melalui aplikasi email perangkat (`mailto:`). Untuk menerima pesan langsung tanpa membuka aplikasi email, hubungkan formulir dengan Google Forms atau layanan formulir lain.

## Gambar
Template menggunakan ilustrasi berbasis CSS dan ikon teks agar tetap dapat dibuka tanpa mengunduh gambar eksternal. Kamu dapat menggantinya dengan foto atau gambar milik sendiri.

## Publikasi
Folder ini adalah template HTML statis, bukan situs Google Sites. Untuk menerbitkan, unggah file ke layanan hosting statis yang kamu gunakan. Jangan mengunggah data pribadi atau rahasia.
